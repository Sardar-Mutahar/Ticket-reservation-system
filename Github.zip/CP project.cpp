#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <limits>
#include <algorithm>
#include <windows.h>

#define TOTAL_SEATS 100  
#define VIP_SEATS 20     
#define PREMIUM_COST 2000
#define NORMAL_COST 1000
#define ROWS 10
#define COLS 10
int DebugEnabled = 0;


using namespace std;


void clearScreen();
void mainMenu();
void adminMenu(int seats[ROWS][COLS], int& totalBill);
int DebugMenu(int seats[ROWS][COLS], int& totalBill, int DebugEnabled);
void displayMovies();
void userMenu(int seats[ROWS][COLS], int& totalBill);
void handleTicketPurchase(int seats[ROWS][COLS], int& totalBill);
void reserveSeats(int seats[ROWS][COLS], int& totalBill, int tickets);
void displaySeats(const int seats[ROWS][COLS]);
void processPayment(int& totalBill);
void displayTicketDetails(const string& name, const string& contact, int timing, int tickets, int totalBill);
void viewMovies();
void modifyMovies();
void saveReceiptToCSV(const string& name, const string& contact, int timing, int tickets, int totalBill);
void clearAndSetBackground();
void loadingBar();
int main() {
    loadingBar();
    int seats[ROWS][COLS] = {0}; // 2D array for seats
    int totalBill = 0; // Total bill

    string adminPassword = "admin123";
    string userPassword = "user123";

    while (true) {
        clearScreen();
        cout << "\n----------------------------------------------------------";
        cout << "\n-                    TICKET RESERVATION SYSTEM            -";
        cout << "\n----------------------------------------------------------";
        cout << "\n---------------1. Admin Login-----------------------------";
        cout << "\n-              2. User Login------------------------------";
        cout << "\n---------------3. Exit------------------------------------";
        cout << "\n---------------------Enter your choice: ------------------";

        int choice;
        while (!(cin >> choice) || choice < 1 || choice > 3) {
            cout << "Invalid input. Please select an option between 1 and 3.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        if (choice == 1) {
            clearScreen();
            string password;
            cout << "Enter Admin Password: ";
            cin >> password;

            if (password == adminPassword) {
                adminMenu(seats, totalBill);
            }
            else {
                cout << "Incorrect password. Returning to main menu.\n";
                system("pause");
            }
        }
        else if (choice == 2) {
            clearScreen();
            string password;
            cout << "Enter User Password: ";
            cin >> password;

            if (password == userPassword) {
                userMenu(seats, totalBill);
            }
            else {
                cout << "Incorrect password. Returning to main menu.\n";
                system("pause");
            }
        }
        else if (choice == 3) {
            cout << "\nThank you for visiting! See you again!\n";
            break;
        }
    }
}

void loadingBar() {
    system("cls");
    system("color CF");
    char a = 177, b = 219;

    cout << "\n\n\n\t\t\t--------- Movie Ticket Reservation System---------------";
    cout << "\n\t\t\t------------------Project by ------------------------------";
    cout<<"\n\t\t\t------------------Cs 1b students--------------------------  ";
    cout << "\n\n\n\t\t\t\t\tLoading...\n\n";
    cout << "\t\t\t\t\t";

    for (int i = 0; i < 26; i++) {
        cout << a;
    }

    cout << "\r";
    cout << "\t\t\t\t\t";
    for (int i = 0; i < 26; i++) {
        cout << b;
        Sleep(100);
    }
    cout << endl;
    

}


void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif

}


void adminMenu(int seats[ROWS][COLS], int& totalBill) {
    while (true) {
        clearScreen();
        cout << "\n         ---------------------------------------------";
        cout << "\n         -              ADMIN MENU                   -";
        cout << "\n         ---------------------------------------------";
        cout << "\n         ------1. View Movie Records------------------";
        cout << "\n         ------2. Modify Movie Records----------------";
        cout << "\n         ------3. Enable Debug Menu-------------------";
        cout << "\n         ------4. Logout------------------------------";
        cout << "\n         ----------- Enter your choice:---------------";

        int choice;
        while (!(cin >> choice) || choice < 1 || choice > 4) {
            cout << "Invalid input. Please select an option between 1 and 4.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        if (choice == 1) {
            viewMovies();
        } else if (choice == 2) {
            modifyMovies();
        } else if (choice == 3) {
            DebugEnabled = 1; // Enable debug mode
            DebugMenu(seats, totalBill, DebugEnabled); // Call DebugMenu
        } else if (choice == 4) {
            break;
        }
    }
}


// User menu
void userMenu(int seats[ROWS][COLS], int& totalBill) {
    char ans;
    do {
        clearScreen();
        mainMenu();

        int choice;
        while (!(cin >> choice) || choice < 1 || choice > 3) {
            cout << "Invalid input. Please select an option between 1 and 3.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        switch (choice) {
        case 1:
            handleTicketPurchase(seats, totalBill);
            break;
        case 2:
            cout << "\nFor inquiries, contact us at 01234567896523.\n";
            break;
        case 3:
            return;
        }

        cout << "\nWould you like to perform another action? (y/n): ";
        cin >> ans;
    } while (ans == 'y' || ans == 'Y');
}

// Main menu for users
void mainMenu() {
    cout << "\n---------------------------------------------";
    cout << "\n-        MOVIE TICKET RESERVATION SYSTEM    -";
    cout << "\n---------------------------------------------";
    cout << "\n---1. Movie and Ticket Reservation-----------";
    cout << "\n---2. Contact Us-----------------------------";
    cout << "\n---3. Exit-----------------------------------";
    cout << "\n-----------Enter your choice:-------------- -";
}

// Handle ticket purchase
void handleTicketPurchase(int seats[ROWS][COLS], int& totalBill) {
    clearScreen();
    int movieChoice, timingChoice, tickets;
    string name, contact;

    displayMovies();
    while (!(cin >> movieChoice) || movieChoice < 1 || movieChoice > 6) {
        cout << "Invalid movie choice. Please try again.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "\nSelect show timing:";
    cout << "\n1. 0800\n2. 1300\n3. 1450\n4. 1800\n5. 2100\n6. 0100\n";
    cout << "Enter your choice: ";
    while (!(cin >> timingChoice) || timingChoice < 1 || timingChoice > 6) {
        cout << "Invalid timing choice. Please try again.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "\nEnter your name: ";
    cin.ignore(); 
    getline(cin, name);

    cout << "Enter your contact number: ";
    cin >> contact;

while (contact.length() != 10) {
    cout << "Invalid number. Please re-enter: ";
    cin >> contact;
}


bool validContact = true;
for (int i = 0; i < 10; i++) {
    if (!isdigit(contact[i])) {
        validContact = false;
        break;
    }
}

while (!validContact) {
    cout << "Invalid number. Please re-enter: ";
    cin >> contact;

  
    validContact = true;
    for (int i = 0; i < 10; i++) {
        if (!isdigit(contact[i])) {
            validContact = false;
            break;
        }
    }
}
    cout << "Enter the number of tickets you want to purchase: ";
    while (!(cin >> tickets) || tickets <= 0) {
        cout << "Invalid number of tickets. Please try again.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    reserveSeats(seats, totalBill, tickets); 

    processPayment(totalBill);
    displayTicketDetails(name, contact, timingChoice, tickets, totalBill);

    
    saveReceiptToCSV(name, contact, timingChoice, tickets, totalBill);
}


void displayMovies() {
    cout << "\nAvailable Movies:";
    ifstream file("movies.txt");
    if (!file) {
        cout << "\nError: Could not open movies file.";
        return;
    }

    string line;
    int count = 1;
    while (getline(file, line)) {
        cout << "\n" << count++ << ". " << line;
    }
    file.close();
    cout << "\nEnter your choice: ";
}


void reserveSeats(int seats[ROWS][COLS], int& totalBill, int tickets) {
    displaySeats(seats);
    cout << "\nPlease select " << tickets << " seat(s).\n";

    for (int i = 0; i < tickets; ++i) {
        char rowChar;
        int row, seatNumber;

        cout << "Enter the row (A-J) for ticket " << (i + 1) << ": ";
        cin >> rowChar;
        row = rowChar - 'A'; // Convert 'A'-'J' to row index 0-9

        while (row < 0 || row >= ROWS) {
            cout << "Invalid row. Please select a row between A and J.\n";
            cin >> rowChar;
            row = rowChar - 'A';
        }

        cout << "Enter the seat number (1-10) for ticket " << (i + 1) << ": ";
        while (!(cin >> seatNumber) || seatNumber < 1 || seatNumber > COLS) {
            cout << "Invalid seat number. Please try again.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        if (seats[row][seatNumber - 1] == 1) {
            cout << "Seat already reserved. Please select another.\n";
            --i;
        } else {
            seats[row][seatNumber - 1] = 1;
            if (row == 0 || row == 1) { // Rows A and B are premium
                totalBill += PREMIUM_COST;
                cout << "Reserved Premium seat. Cost: " << PREMIUM_COST << " PKR\n";
            } else {
                totalBill += NORMAL_COST;
                cout << "Reserved Normal seat. Cost: " << NORMAL_COST << " PKR\n";
            }
        }
    }

   
    cout << "\nUpdated Seat Layout:\n";
    displaySeats(seats);
}

void displaySeats(const int seats[ROWS][COLS]) {
    cout << "\nSeat Layout:\n";
    char rowLabel = 'A';  

    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j) {
            cout << "[" << rowLabel << "-" << (j + 1) << "] ";
      
            cout << (seats[i][j] == 0 ? "[ ]" : "[X]") << " ";
        }
        cout << "\n";
        rowLabel++; 
    }
    cout << "\n";
}

void processPayment(int& totalBill) {
    char cardHolder;
    cout << "\nDo you have a loyalty card? (y/n): ";
    cin >> cardHolder;

    if (cardHolder == 'y' || cardHolder == 'Y') {
        totalBill -= static_cast<int>(0.1 * totalBill); 
        cout << "Discount applied. ";
    }

    cout << "Total payment: " << totalBill << " PKR\n";
}


void displayTicketDetails(const string& name, const string& contact, int timing, int tickets, int totalBill) {
    cout << "\nTicket Details:";
    cout << "\nName: " << name;
    cout << "\nContact: " << contact;
    cout << "\nTiming: ";
    switch (timing) {
    case 1: cout << "0800"; break;
    case 2: cout << "1300"; break;
    case 3: cout << "1450"; break;
    case 4: cout << "1800"; break;
    case 5: cout << "2100"; break;
    case 6: cout << "0100"; break;
    default: cout << "Invalid timing"; break;
    }
    cout << "\nTickets: " << tickets;
    cout << "\nTotal Bill: " << totalBill << " PKR\n";
}


void saveReceiptToCSV(const string& name, const string& contact, int timing, int tickets, int totalBill) {
    ofstream file("ticket_receipt.csv", ios::app);

    if (!file) {
        cout << "Error opening file for writing.\n";
        return;
    }

    file << name << ","
         << contact << ","
         << (timing == 1 ? "0800" : timing == 2 ? "1300" : timing == 3 ? "1450" : timing == 4 ? "1800" : timing == 5 ? "2100" : "0100")
         << "," << tickets << ","
         << totalBill << "\n";

    file.close();
    cout << "Receipt saved to 'ticket_receipt.csv' successfully.\n";
}

void viewMovies() {
    ifstream file("movies.txt");
    if (!file) {
        cout << "\nError: Could not open movies file.";
        return;
    }

    cout << "\nMovie Records:";
    string line;
    int count = 1;
    while (getline(file, line)) {
        cout << "\n" << count++ << ". " << line;
    }
    file.close();
    cout << "\n";
    system("pause");
}

void modifyMovies() {
    ofstream file("movies.txt", ios::app);
    if (!file) {
        cout << "\nError: Could not open movies file.";
        return;
    }

    cout << "\nEnter a new movie to add: ";
    cin.ignore(); 
    string movie;
    getline(cin, movie);

    file << movie << endl;
    file.close();
    cout << "\nMovie added successfully.\n";
    system("pause");
}

int DebugMenu(int seats[ROWS][COLS], int& totalBill, int DebugEnabled) {
    if (!DebugEnabled) {
        cout << "Debug mode is disabled. Returning to Admin Menu.\n";
        system("pause");
        return 0;
    }

    clearScreen();
    cout << "Welcome to the 'DEBUG MENU'\n";
    cout << "-----------------------------------------------\n";

    while (true) {
       
        cout << "\nDebug Menu Options:\n";
        cout << "1.  Admin Menu function\n";
        cout << "2.  Display Movies function\n";
        cout << "3.  Modify Movies Function\n";
        cout << "4. Exit Debug Menu\n";
        cout << "-----------------------------------------------\n";
        cout << "Enter your choice: ";

        int n;
        cin >> n;

      
        switch (n) {
            case 1:
              adminMenu(seats, totalBill); 
            case 2:
                displayMovies(); 
                break;
            case 3:
               modifyMovies(); 
                break;
            case 4:
                  cout << "Exiting Debug Menu...\n";
                break;
            
              
                return 0; 
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    }
    return 0; 
}



